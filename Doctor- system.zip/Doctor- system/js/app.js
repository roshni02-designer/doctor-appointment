// REGISTER
document.getElementById("registerForm")?.addEventListener("submit", function(e){
  e.preventDefault();

  let user = {
    name: name.value,
    email: email.value,
    password: password.value
  };

  localStorage.setItem("user", JSON.stringify(user));
  alert("Registered!");
  window.location.href = "login.html";
});

// LOGIN
document.getElementById("loginForm")?.addEventListener("submit", function(e){
  e.preventDefault();

  let user = JSON.parse(localStorage.getItem("user"));

  if(user && user.email === loginEmail.value && user.password === loginPassword.value){
    alert("Login Success");
    window.location.href = "dashboard.html";
  } else {
    alert("Wrong Info");
  }
});

// LOGOUT
function logout(){
  localStorage.removeItem("user");
  window.location.href = "login.html";
}

// BOOK APPOINTMENT
function book(){
  let appointment = {
    date: date.value,
    time: time.value,
    status: "Pending"
  };

  localStorage.setItem("appointment", JSON.stringify(appointment));
  alert("Booked!");
}

// VIEW STATUS
function viewStatus(){
  let data = JSON.parse(localStorage.getItem("appointment"));

  if(data){
    document.getElementById("status").innerHTML =
      data.date + " | " + data.time + " | " + data.status;
  } else {
    document.getElementById("status").innerHTML = "No appointment";
  }
}